# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
PeoplesC::Application.config.secret_key_base = '6c291efaa8c2d9796cc32206d4327f1f15d26e840741ac775d061994fb0c4a89cd34380df807e1a9ee94841771bbefcb027f6e8cf730ca915dc5db4a5d0a2d28'
