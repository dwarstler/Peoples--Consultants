module PictureHelper
end
